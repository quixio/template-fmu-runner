"""
QuixLake Client

Main client class for interacting with QuixLake API endpoints.
"""

import requests
import pandas as pd
import io
from typing import Optional, List, Dict, Any
from urllib.parse import urljoin


class QuixLakeClient:
    """
    Client for interacting with QuixLake API.
    
    Provides convenient methods for querying, inserting, and managing data
    without having to handle HTTP requests and response parsing manually.
    """
    
    def __init__(self, base_url: str = "http://localhost", token: Optional[str] = None, timeout: int = 30):
        """
        Initialize QuixLake client.

        Args:
            base_url: Base URL of the QuixLake API (default: http://localhost)
            token: Authentication token for API access (default: None)
            timeout: Request timeout in seconds (default: 30)
        """
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.timeout = timeout
        self.session = requests.Session()
        if token:
            self.session.headers.update({"Authorization": f"Bearer {token}"})
        
    def query(self, sql: str, explain_analyze: bool = False, union_by_name: bool = True) -> pd.DataFrame:
        """
        Execute a SQL query and return results as pandas DataFrame.

        Args:
            sql: SQL query string (SELECT statements only)
            explain_analyze: Enable query execution plan analysis (default: False)
            union_by_name: Use UNION ALL BY NAME for schema evolution support (default: True)

        Returns:
            pandas DataFrame with query results

        Raises:
            ValueError: If query is invalid or returns an error
            requests.RequestException: If HTTP request fails
        """
        url = urljoin(self.base_url, "/query")
        params = {
            "explain": "true" if explain_analyze else "false",
            "union_by_name": "true" if union_by_name else "false"
        }
        
        response = self.session.post(
            url, 
            data=sql, 
            params=params,
            timeout=self.timeout,
            headers={"Content-Type": "text/plain"}
        )
        
        if response.status_code == 200:
            # Parse CSV response
            csv_data = response.text
            return pd.read_csv(io.StringIO(csv_data))
        else:
            error_data = response.json() if response.headers.get('content-type') == 'application/json' else {"error": response.text}
            raise ValueError(f"Query failed: {error_data.get('error', 'Unknown error')}")
    
    def get_tables(self) -> List[str]:
        """
        Get list of available tables.
        
        Returns:
            List of table names
        """
        url = urljoin(self.base_url, "/tables")
        response = self.session.get(url, timeout=self.timeout)
        response.raise_for_status()
        return response.json().get("tables", [])
    
    def get_partitions(self, table_name: str) -> Dict[str, Any]:
        """
        Get partition tree structure for a table.
        
        Args:
            table_name: Name of the table
            
        Returns:
            Dictionary containing partition tree structure
        """
        url = urljoin(self.base_url, "/partitions")
        params = {"table": table_name}
        response = self.session.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
    
    def get_partition_info(self, table_name: str) -> Dict[str, Any]:
        """
        Get partition structure information for a table.
        
        Args:
            table_name: Name of the table
            
        Returns:
            Dictionary containing partition structure info
        """
        url = urljoin(self.base_url, "/partition-info")
        params = {"table": table_name}
        response = self.session.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
    
    def insert(self, 
               table_name: str, 
               data: pd.DataFrame,
               hive_columns: Optional[List[str]] = None,
               timestamp_column: Optional[str] = None,
               timestamp_format: str = "day") -> Dict[str, Any]:
        """
        Insert data into a table with optional partitioning.
        
        Args:
            table_name: Name of the target table
            data: pandas DataFrame containing the data to insert
            hive_columns: List of columns to use for Hive partitioning
            timestamp_column: Column to use for timestamp-based partitioning
            timestamp_format: Format for timestamp partitioning ('day', 'hour', 'month')
            
        Returns:
            Dictionary containing insertion results
        """
        url = urljoin(self.base_url, "/insert")
        params = {"table": table_name}
        
        if hive_columns:
            params["hive_columns"] = ",".join(hive_columns)
        if timestamp_column:
            params["timestamp_column"] = timestamp_column
        if timestamp_format:
            params["timestamp_format"] = timestamp_format
            
        # Convert DataFrame to CSV
        csv_data = data.to_csv(index=False)
        
        response = self.session.post(
            url,
            data=csv_data,
            params=params,
            timeout=self.timeout,
            headers={"Content-Type": "text/plain"}
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 409:
            # Partition structure mismatch
            error_data = response.json()
            raise ValueError(f"Partition mismatch: {error_data.get('error', 'Unknown error')}")
        else:
            response.raise_for_status()
    
    def compact(self, table_name: str, target_file_size_mb: int = 128) -> Dict[str, Any]:
        """
        Compact table files to optimize performance.
        
        Args:
            table_name: Name of the table to compact
            target_file_size_mb: Target size for compacted files in MB
            
        Returns:
            Dictionary containing compaction results
        """
        url = urljoin(self.base_url, "/compact")
        params = {
            "table": table_name,
            "target_file_size_mb": target_file_size_mb
        }
        
        response = self.session.post(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
    
    def repartition(self,
                   table_name: str,
                   hive_columns: Optional[List[str]] = None,
                   timestamp_column: Optional[str] = None,
                   timestamp_format: str = "day",
                   target_file_size_mb: int = 128) -> Dict[str, Any]:
        """
        Repartition table data with new partition scheme.
        
        Args:
            table_name: Name of the table to repartition
            hive_columns: List of columns to use for new partitioning scheme
            timestamp_column: Column to use for timestamp-based partitioning
            timestamp_format: Format for timestamp partitioning ('day', 'hour', 'month')
            target_file_size_mb: Target size for files in MB
            
        Returns:
            Dictionary containing repartitioning results
        """
        url = urljoin(self.base_url, "/repartition")
        params = {
            "table": table_name,
            "target_file_size_mb": target_file_size_mb
        }
        
        if hive_columns:
            params["hive_columns"] = ",".join(hive_columns)
        if timestamp_column:
            params["timestamp_column"] = timestamp_column
        if timestamp_format:
            params["timestamp_format"] = timestamp_format
            
        response = self.session.post(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
    
    def delete(self,
               table_name: str,
               where_clause: Optional[str] = None,
               delete_table: bool = False,
               partitions: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Delete data from table with various deletion modes.
        
        Args:
            table_name: Name of the table
            where_clause: SQL WHERE clause for conditional deletion
            delete_table: Whether to delete the entire table
            partitions: List of specific partitions to delete
            
        Returns:
            Dictionary containing deletion results
        """
        url = urljoin(self.base_url, "/delete")
        params = {"table": table_name}
        
        if where_clause:
            params["where"] = where_clause
        if delete_table:
            params["delete_table"] = "true"
        if partitions:
            params["partitions"] = ",".join(partitions)
            
        response = self.session.delete(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        return response.json()
    
    def __enter__(self):
        """Context manager entry."""
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.session.close()